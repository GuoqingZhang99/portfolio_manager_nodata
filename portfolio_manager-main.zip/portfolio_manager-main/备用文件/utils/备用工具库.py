"""
备用工具库 (Backup Utilities)
===============================

这个文件存放暂时未使用但将来可能需要的工具函数。

使用说明：
---------
如果需要使用这里的函数，可以这样导入：
    from utils.备用工具库 import get_realtime_quote, format_volume

添加新的备用工具：
-----------------
将来如果有其他暂时不用但想保留的工具函数，可以添加到这个文件中。

最后更新：2026-01-05
"""

from yahooquery import Ticker
import pandas as pd


# ============================================================================
# 实时价格模块
# 用于Dashboard集成和实时价格监控
# 来源：utils/realtime_price.py
# ============================================================================

def get_realtime_quote(symbol):
    """
    获取单个股票的实时报价

    Args:
        symbol: 股票代码

    Returns:
        dict: 包含实时价格信息的字典，包括：
            - symbol: 股票代码
            - price: 当前价格
            - change: 涨跌额
            - change_percent: 涨跌幅
            - volume: 成交量
            - day_high/day_low: 日内高低
            - open: 开盘价
            - prev_close: 昨收价
            - bid/ask: 买卖价
            - market_state: 市场状态
            - market_cap: 市值
            - avg_volume: 平均成交量
    """
    try:
        stock = Ticker(symbol)
        price_data = stock.price

        if symbol not in price_data or not isinstance(price_data[symbol], dict):
            return None

        data = price_data[symbol]
        market_state = data.get('marketState', 'UNKNOWN')

        # 根据市场状态选择对应的价格
        if market_state == 'REGULAR':  # 盘中
            current_price = data.get('regularMarketPrice')
            change = data.get('regularMarketChange')
            change_percent = data.get('regularMarketChangePercent')
            volume = data.get('regularMarketVolume')
            day_high = data.get('regularMarketDayHigh')
            day_low = data.get('regularMarketDayLow')
            open_price = data.get('regularMarketOpen')
        elif market_state == 'POST':  # 盘后
            current_price = data.get('postMarketPrice') or data.get('regularMarketPrice')
            change = data.get('postMarketChange') or data.get('regularMarketChange')
            change_percent = data.get('postMarketChangePercent') or data.get('regularMarketChangePercent')
            volume = data.get('regularMarketVolume')
            day_high = data.get('regularMarketDayHigh')
            day_low = data.get('regularMarketDayLow')
            open_price = data.get('regularMarketOpen')
        elif market_state == 'PRE':  # 盘前
            current_price = data.get('preMarketPrice') or data.get('regularMarketPrice')
            change = data.get('preMarketChange') or data.get('regularMarketChange')
            change_percent = data.get('preMarketChangePercent') or data.get('regularMarketChangePercent')
            volume = data.get('regularMarketVolume')
            day_high = data.get('regularMarketDayHigh')
            day_low = data.get('regularMarketDayLow')
            open_price = data.get('regularMarketOpen')
        else:  # 休市
            current_price = data.get('regularMarketPrice')
            change = data.get('regularMarketChange')
            change_percent = data.get('regularMarketChangePercent')
            volume = data.get('regularMarketVolume')
            day_high = data.get('regularMarketDayHigh')
            day_low = data.get('regularMarketDayLow')
            open_price = data.get('regularMarketOpen')

        return {
            'symbol': symbol,
            'price': current_price,
            'change': change,
            'change_percent': change_percent,
            'volume': volume,
            'day_high': day_high,
            'day_low': day_low,
            'open': open_price,
            'prev_close': data.get('regularMarketPreviousClose'),
            'bid': data.get('bid'),
            'ask': data.get('ask'),
            'market_state': market_state,
            'market_cap': data.get('marketCap'),
            'avg_volume': data.get('averageDailyVolume10Day'),
        }

    except Exception as e:
        print(f"获取{symbol}实时报价失败: {e}")
        return None


def get_realtime_quotes_batch(symbols):
    """
    批量获取多个股票的实时报价

    Args:
        symbols: 股票代码列表

    Returns:
        pandas.DataFrame: 包含实时价格信息的DataFrame
    """
    try:
        tickers = Ticker(symbols)
        prices_data = tickers.price

        results = []
        for symbol in symbols:
            if symbol in prices_data and isinstance(prices_data[symbol], dict):
                data = prices_data[symbol]
                market_state = data.get('marketState', 'UNKNOWN')

                # 根据市场状态选择对应的价格
                if market_state == 'REGULAR':  # 盘中
                    current_price = data.get('regularMarketPrice')
                    change = data.get('regularMarketChange')
                    change_percent = data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    day_high = data.get('regularMarketDayHigh')
                    day_low = data.get('regularMarketDayLow')
                    open_price = data.get('regularMarketOpen')
                elif market_state == 'POST':  # 盘后
                    current_price = data.get('postMarketPrice') or data.get('regularMarketPrice')
                    change = data.get('postMarketChange') or data.get('regularMarketChange')
                    change_percent = data.get('postMarketChangePercent') or data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    day_high = data.get('regularMarketDayHigh')
                    day_low = data.get('regularMarketDayLow')
                    open_price = data.get('regularMarketOpen')
                elif market_state == 'PRE':  # 盘前
                    current_price = data.get('preMarketPrice') or data.get('regularMarketPrice')
                    change = data.get('preMarketChange') or data.get('regularMarketChange')
                    change_percent = data.get('preMarketChangePercent') or data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    day_high = data.get('regularMarketDayHigh')
                    day_low = data.get('regularMarketDayLow')
                    open_price = data.get('regularMarketOpen')
                else:  # 休市
                    current_price = data.get('regularMarketPrice')
                    change = data.get('regularMarketChange')
                    change_percent = data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    day_high = data.get('regularMarketDayHigh')
                    day_low = data.get('regularMarketDayLow')
                    open_price = data.get('regularMarketOpen')

                results.append({
                    '股票代码': symbol,
                    '当前价格': current_price,
                    '涨跌额': change,
                    '涨跌幅(%)': change_percent,
                    '成交量': volume,
                    '日内高': day_high,
                    '日内低': day_low,
                    '开盘价': open_price,
                    '昨收价': data.get('regularMarketPreviousClose'),
                    '买价': data.get('bid'),
                    '卖价': data.get('ask'),
                    '市场状态': market_state,
                    '市值': data.get('marketCap'),
                    '平均成交量': data.get('averageDailyVolume10Day'),
                })

        return pd.DataFrame(results)

    except Exception as e:
        print(f"批量获取实时报价失败: {e}")
        return pd.DataFrame()


def get_market_state_cn(state):
    """
    将市场状态转换为中文

    Args:
        state: 市场状态英文

    Returns:
        str: 中文状态
    """
    state_map = {
        'REGULAR': '盘中',
        'POST': '盘后',
        'PRE': '盘前',
        'CLOSED': '休市',
        'PREPRE': '准备中'
    }
    return state_map.get(state, state)


def format_volume(volume):
    """
    格式化成交量

    Args:
        volume: 成交量

    Returns:
        str: 格式化后的成交量（如 1.5M, 2.3B）
    """
    if volume is None or volume == 0:
        return 'N/A'

    if volume >= 1_000_000_000:
        return f"{volume / 1_000_000_000:.2f}B"
    elif volume >= 1_000_000:
        return f"{volume / 1_000_000:.2f}M"
    elif volume >= 1_000:
        return f"{volume / 1_000:.2f}K"
    else:
        return str(volume)


def format_market_cap(market_cap):
    """
    格式化市值

    Args:
        market_cap: 市值

    Returns:
        str: 格式化后的市值（如 $1.5T, $2.3B）
    """
    if market_cap is None or market_cap == 0:
        return 'N/A'

    if market_cap >= 1_000_000_000_000:
        return f"${market_cap / 1_000_000_000_000:.2f}T"
    elif market_cap >= 1_000_000_000:
        return f"${market_cap / 1_000_000_000:.2f}B"
    elif market_cap >= 1_000_000:
        return f"${market_cap / 1_000_000:.2f}M"
    else:
        return f"${market_cap:.2f}"


def is_market_open_now():
    """
    检查市场当前是否开盘

    Returns:
        tuple: (是否开盘, 市场状态)

    示例:
        is_open, state = is_market_open_now()
        if is_open:
            print(f"市场开盘中，状态: {state}")
    """
    try:
        # 用一个常见股票检查市场状态
        stock = Ticker('SPY')
        price_data = stock.price

        if 'SPY' in price_data and isinstance(price_data['SPY'], dict):
            market_state = price_data['SPY'].get('marketState', 'UNKNOWN')
            is_open = market_state in ['REGULAR', 'PRE', 'POST']
            return is_open, market_state
        else:
            return False, 'UNKNOWN'

    except Exception:
        return False, 'UNKNOWN'


# ============================================================================
# 在这里添加更多备用工具函数
# ============================================================================

# 示例：
# def 你的备用函数():
#     """
#     函数说明
#     """
#     pass
