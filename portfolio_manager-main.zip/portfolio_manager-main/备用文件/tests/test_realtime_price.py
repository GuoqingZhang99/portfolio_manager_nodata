"""
测试实时价格获取
展示 yahooquery 提供的所有实时价格信息
"""
import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32' and hasattr(sys.stdout, 'buffer'):
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except:
        pass

from yahooquery import Ticker
from datetime import datetime
import time

def get_realtime_data(symbol):
    """获取实时价格数据"""
    stock = Ticker(symbol)

    # 获取价格信息
    price_data = stock.price

    if symbol not in price_data or not isinstance(price_data[symbol], dict):
        return None

    data = price_data[symbol]

    # 提取所有相关信息
    result = {
        'symbol': symbol,
        'current_price': None,
        'change': None,
        'change_percent': None,
        'market_state': None,
        'bid': None,
        'ask': None,
        'volume': None,
        'avg_volume': None,
        'market_cap': None,
        'day_high': None,
        'day_low': None,
        'open': None,
        'prev_close': None,
        'timestamp': None
    }

    # 判断市场状态并获取对应价格
    market_state = data.get('marketState', 'UNKNOWN')
    result['market_state'] = market_state

    # 获取当前价格（根据市场状态）
    if market_state == 'REGULAR':  # 盘中
        result['current_price'] = data.get('regularMarketPrice')
        result['change'] = data.get('regularMarketChange')
        result['change_percent'] = data.get('regularMarketChangePercent')
        result['volume'] = data.get('regularMarketVolume')
        result['day_high'] = data.get('regularMarketDayHigh')
        result['day_low'] = data.get('regularMarketDayLow')
        result['open'] = data.get('regularMarketOpen')
        result['prev_close'] = data.get('regularMarketPreviousClose')
    elif market_state == 'POST':  # 盘后
        result['current_price'] = data.get('postMarketPrice') or data.get('regularMarketPrice')
        result['change'] = data.get('postMarketChange') or data.get('regularMarketChange')
        result['change_percent'] = data.get('postMarketChangePercent') or data.get('regularMarketChangePercent')
        result['volume'] = data.get('regularMarketVolume')
        result['day_high'] = data.get('regularMarketDayHigh')
        result['day_low'] = data.get('regularMarketDayLow')
        result['open'] = data.get('regularMarketOpen')
        result['prev_close'] = data.get('regularMarketPreviousClose')
    elif market_state == 'PRE':  # 盘前
        result['current_price'] = data.get('preMarketPrice') or data.get('regularMarketPrice')
        result['change'] = data.get('preMarketChange') or data.get('regularMarketChange')
        result['change_percent'] = data.get('preMarketChangePercent') or data.get('regularMarketChangePercent')
        result['volume'] = data.get('regularMarketVolume')
        result['prev_close'] = data.get('regularMarketPreviousClose')
    else:  # 其他状态（休市等）
        result['current_price'] = data.get('regularMarketPrice')
        result['change'] = data.get('regularMarketChange')
        result['change_percent'] = data.get('regularMarketChangePercent')
        result['volume'] = data.get('regularMarketVolume')
        result['day_high'] = data.get('regularMarketDayHigh')
        result['day_low'] = data.get('regularMarketDayLow')
        result['open'] = data.get('regularMarketOpen')
        result['prev_close'] = data.get('regularMarketPreviousClose')

    # 买卖价
    result['bid'] = data.get('bid')
    result['ask'] = data.get('ask')

    # 其他信息
    result['avg_volume'] = data.get('averageDailyVolume10Day')
    result['market_cap'] = data.get('marketCap')

    return result


def format_price_display(data):
    """格式化价格显示"""
    if not data:
        return "无数据"

    lines = []
    lines.append("=" * 70)
    lines.append(f"股票: {data['symbol']}")
    lines.append(f"市场状态: {data['market_state']}")
    lines.append(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("-" * 70)

    # 当前价格
    if data['current_price']:
        price = data['current_price']
        change = data['change'] or 0
        change_pct = data['change_percent'] or 0

        # 涨跌符号
        if change > 0:
            sign = "+"
            trend = "↑"
        elif change < 0:
            sign = ""
            trend = "↓"
        else:
            sign = " "
            trend = "→"

        lines.append(f"当前价格: ${price:.2f} {trend}")
        lines.append(f"涨跌额:   {sign}${change:.2f}")
        lines.append(f"涨跌幅:   {sign}{change_pct:.2f}%")

    # 日内高低
    if data['day_high'] and data['day_low']:
        lines.append(f"日内高:   ${data['day_high']:.2f}")
        lines.append(f"日内低:   ${data['day_low']:.2f}")

    # 开盘/收盘
    if data['open']:
        lines.append(f"开盘价:   ${data['open']:.2f}")
    if data['prev_close']:
        lines.append(f"昨收价:   ${data['prev_close']:.2f}")

    # 买卖价
    if data['bid'] and data['ask']:
        lines.append(f"买价:     ${data['bid']:.2f}")
        lines.append(f"卖价:     ${data['ask']:.2f}")
        spread = data['ask'] - data['bid']
        lines.append(f"价差:     ${spread:.2f}")

    # 成交量
    if data['volume']:
        vol_m = data['volume'] / 1_000_000
        lines.append(f"成交量:   {vol_m:.2f}M")

    if data['avg_volume']:
        avg_vol_m = data['avg_volume'] / 1_000_000
        lines.append(f"日均量:   {avg_vol_m:.2f}M")

    # 市值
    if data['market_cap']:
        cap_b = data['market_cap'] / 1_000_000_000
        lines.append(f"市值:     ${cap_b:.2f}B")

    lines.append("=" * 70)

    return "\n".join(lines)


def display_price_info(symbol):
    """显示单个股票的实时价格信息"""
    print(f"\n正在获取 {symbol} 的实时数据...\n")

    data = get_realtime_data(symbol)
    print(format_price_display(data))


def display_multiple_prices(symbols):
    """显示多个股票的实时价格"""
    print("\n" + "=" * 70)
    print(f"批量获取 {len(symbols)} 个股票的实时价格")
    print("=" * 70 + "\n")

    tickers = Ticker(symbols)
    prices_data = tickers.price

    results = []
    for symbol in symbols:
        if symbol in prices_data and isinstance(prices_data[symbol], dict):
            data = prices_data[symbol]

            # 获取当前价格
            market_state = data.get('marketState', 'UNKNOWN')
            if market_state == 'REGULAR':
                price = data.get('regularMarketPrice')
                change = data.get('regularMarketChange')
                change_pct = data.get('regularMarketChangePercent')
            elif market_state == 'POST':
                price = data.get('postMarketPrice') or data.get('regularMarketPrice')
                change = data.get('postMarketChange') or data.get('regularMarketChange')
                change_pct = data.get('postMarketChangePercent') or data.get('regularMarketChangePercent')
            else:
                price = data.get('regularMarketPrice')
                change = data.get('regularMarketChange')
                change_pct = data.get('regularMarketChangePercent')

            results.append({
                'symbol': symbol,
                'price': price,
                'change': change or 0,
                'change_pct': change_pct or 0,
                'state': market_state
            })

    # 表格显示
    print(f"{'股票':<8} {'状态':<10} {'价格':<12} {'涨跌额':<12} {'涨跌幅':<10}")
    print("-" * 70)

    for r in results:
        if r['change'] > 0:
            sign = "+"
            trend = "↑"
        elif r['change'] < 0:
            sign = ""
            trend = "↓"
        else:
            sign = " "
            trend = "→"

        state_cn = {
            'REGULAR': '盘中',
            'POST': '盘后',
            'PRE': '盘前',
            'CLOSED': '休市',
            'PREPRE': '盘前准备'
        }.get(r['state'], r['state'])

        print(f"{r['symbol']:<8} {state_cn:<10} ${r['price']:<11.2f} {sign}${abs(r['change']):<10.2f} {sign}{r['change_pct']:<9.2f}% {trend}")

    print("=" * 70)


if __name__ == "__main__":
    # 测试单个股票详细信息
    print("\n" + "=" * 70)
    print("测试 1: 单个股票详细信息")
    print("=" * 70)

    display_price_info('MU')

    time.sleep(1)

    # 测试多个股票批量获取
    print("\n\n" + "=" * 70)
    print("测试 2: 多个股票批量获取")
    print("=" * 70)

    test_symbols = ['MU', 'PLTR', 'NVDA', 'TSLA', 'AMD', 'INTC', 'NFLX', 'ORCL']
    display_multiple_prices(test_symbols)

    print("\n提示: 虽然现在休市，但数据结构是完整的。")
    print("      盘中时，会显示实时价格、买卖价差、成交量等信息。")
