"""
测试 yahooquery 数据源
"""
import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32' and hasattr(sys.stdout, 'buffer'):
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except:
        pass

from yahooquery import Ticker
import time

print("=" * 60)
print("测试 yahooquery 价格获取")
print("=" * 60)

# 测试股票
test_symbols = ['MU', 'PLTR', 'NVDA', 'TSLA']

print(f"\n正在测试 {len(test_symbols)} 个股票...\n")

results = {}
for i, symbol in enumerate(test_symbols, 1):
    print(f"[{i}/{len(test_symbols)}] 获取 {symbol} 价格...", end=' ')
    start_time = time.time()

    try:
        stock = Ticker(symbol)

        # 方法1: 使用 price 属性（最新价格）
        price_data = stock.price

        if symbol in price_data and isinstance(price_data[symbol], dict):
            # 尝试获取当前价格
            price = price_data[symbol].get('regularMarketPrice') or \
                    price_data[symbol].get('postMarketPrice') or \
                    price_data[symbol].get('preMarketPrice')

            if price:
                elapsed = time.time() - start_time
                results[symbol] = {'price': price, 'time': elapsed, 'success': True}
                print(f"${price:.2f} ✅ ({elapsed:.2f}秒)")
            else:
                elapsed = time.time() - start_time
                results[symbol] = {'price': None, 'time': elapsed, 'success': False}
                print(f"失败 ❌ ({elapsed:.2f}秒) - 无价格数据")
        else:
            elapsed = time.time() - start_time
            results[symbol] = {'price': None, 'time': elapsed, 'success': False}
            print(f"失败 ❌ ({elapsed:.2f}秒) - 无效响应")

    except Exception as e:
        elapsed = time.time() - start_time
        results[symbol] = {'price': None, 'time': elapsed, 'success': False}
        print(f"失败 ❌ ({elapsed:.2f}秒) - {str(e)[:50]}")

    # 不需要太长间隔
    if i < len(test_symbols):
        time.sleep(0.5)

# 统计
print("\n" + "=" * 60)
print("测试结果汇总:")
print("-" * 60)

success_count = sum(1 for r in results.values() if r['success'])
total_time = sum(r['time'] for r in results.values())
avg_time = total_time / len(results) if results else 0

print(f"成功率: {success_count}/{len(test_symbols)} ({success_count/len(test_symbols)*100:.0f}%)")
print(f"平均响应时间: {avg_time:.2f} 秒")
print(f"总耗时: {total_time:.2f} 秒")

if success_count > 0:
    print("\n✅ yahooquery 数据源工作正常！")
else:
    print("\n❌ yahooquery 数据源获取失败")

print("=" * 60)

# 显示获取的价格
print("\n获取的价格:")
print("-" * 60)
for symbol, result in results.items():
    if result['success']:
        print(f"{symbol:6} ${result['price']:>8.2f}")
    else:
        print(f"{symbol:6} {'N/A':>8}")
print("=" * 60)

# 测试批量获取
print("\n\n测试批量获取:")
print("-" * 60)
try:
    print(f"批量获取 {len(test_symbols)} 个股票...", end=' ')
    start_time = time.time()

    tickers = Ticker(test_symbols)
    prices_data = tickers.price

    elapsed = time.time() - start_time
    print(f"完成 ({elapsed:.2f}秒)")

    batch_results = {}
    for symbol in test_symbols:
        if symbol in prices_data and isinstance(prices_data[symbol], dict):
            price = prices_data[symbol].get('regularMarketPrice') or \
                    prices_data[symbol].get('postMarketPrice') or \
                    prices_data[symbol].get('preMarketPrice')
            if price:
                batch_results[symbol] = price

    print(f"\n批量获取成功: {len(batch_results)}/{len(test_symbols)}")
    for symbol, price in batch_results.items():
        print(f"  {symbol}: ${price:.2f}")

    print("\n✅ 批量获取功能正常，可以进一步提升性能！")

except Exception as e:
    print(f"失败 ❌ - {str(e)[:100]}")

print("=" * 60)
