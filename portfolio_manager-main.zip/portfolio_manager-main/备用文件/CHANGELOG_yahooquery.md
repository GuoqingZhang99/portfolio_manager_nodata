# 数据源迁移：yfinance → yahooquery

## 更新日期
2026-01-03

## 背景
yfinance 被临时封禁，所有请求超时失败（45-60秒）。寻找替代方案。

## 解决方案
使用 `yahooquery` 替代 `yfinance`，性能更好，速率限制更宽松。

## 主要改动

### 1. 数据源切换
- **主数据源**：yahooquery（新）
- **备份方案**：yfinance（保留作为备份）
- **历史备份**：Alpha Vantage（保留）

### 2. 性能提升
| 指标 | yfinance | yahooquery | 提升 |
|------|----------|------------|------|
| 单股票响应时间 | 45-60秒（超时） | ~1秒 | 45-60倍 ✅ |
| 批量获取4股票 | 超时失败 | 1.33秒 | 成功 ✅ |
| 批量获取8股票 | 超时失败 | ~2秒 | 成功 ✅ |
| 成功率 | 0% | 100% | ✅ |

### 3. 批量获取优化
```python
# 旧实现（yfinance）：逐个获取，9个股票需要9次API调用
for symbol in symbols:
    price = get_current_price(symbol)  # 每次1个
    time.sleep(1.5)  # 间隔1.5秒，总耗时13.5秒+

# 新实现（yahooquery）：批量获取，9个股票只需1次API调用
tickers = Ticker(symbols)  # 一次性获取所有
prices_data = tickers.price  # 总耗时~2秒
```

### 4. 配置优化
| 配置项 | 旧值 | 新值 | 说明 |
|--------|------|------|------|
| check_interval | 300秒 | 30秒 | 批量获取更快，可以更频繁检查 |
| enable_dynamic_interval | True | False | 使用固定30秒间隔 |
| target_requests_per_hour | 240次 | 120次 | 批量获取减少API调用 |

### 5. API调用量对比（9个股票）
| 场景 | yfinance（旧） | yahooquery（新） | 节省 |
|------|---------------|-----------------|------|
| 单次检查 | 9次API调用 | 1次API调用 | 89% ↓ |
| 30秒间隔，1小时 | 1080次 | 120次 | 89% ↓ |
| 盘后使用缓存 | 9次（首次）| 1次（首次）| 89% ↓ |

## 代码改动

### utils/data_fetcher.py
```python
# 新增
from yahooquery import Ticker

# 主函数改用yahooquery
def get_current_price(symbol):
    stock = Ticker(symbol)
    price_data = stock.price
    return price_data[symbol].get('regularMarketPrice')

# 批量获取优化
def batch_get_prices(symbols):
    tickers = Ticker(symbols)  # 批量获取
    prices_data = tickers.price
    # 处理结果...
```

### config.py
```python
ALERT_MONITORING_CONFIG = {
    'check_interval': 30,  # 30秒（原300秒）
    'enable_dynamic_interval': False,  # 禁用（原True）
    'target_requests_per_hour': 120,  # 120次（原240次）
}
```

## 测试结果

### 单股票测试
```
[1/4] 获取 MU 价格... $315.42 ✅ (1.00秒)
[2/4] 获取 PLTR 价格... $167.86 ✅ (1.11秒)
[3/4] 获取 NVDA 价格... $188.85 ✅ (1.31秒)
[4/4] 获取 TSLA 价格... $438.07 ✅ (1.03秒)

成功率: 4/4 (100%)
平均响应时间: 1.11 秒
```

### 批量获取测试
```
批量获取 4 个股票... 完成 (1.33秒)
批量获取成功: 4/4

批量获取 8 个股票... 完成 (~2秒)
批量获取成功: 8/8
```

### 完整流程测试
```
✅ AMD: $223.47
✅ INTC: $39.38
✅ IRDM: $17.76
✅ MU: $315.42
✅ NFLX: $90.99
✅ NVDA: $188.85
✅ ORCL: $195.71
✅ TSLA: $438.07

总耗时: ~2秒
成功率: 100%
```

## 依赖变更

### 新增依赖
```bash
pip install yahooquery
```

### 已安装版本
- yahooquery==2.4.1
- pandas==2.3.3（从2.1.4升级）
- curl-cffi==0.14.0
- requests-futures==1.0.2
- tqdm==4.67.1

## 兼容性

### 保留的备份实现
1. `get_current_price_yfinance()` - yfinance备份
2. `get_current_price_alphavantage()` - Alpha Vantage备份

### 降级策略
批量获取失败时，自动降级到逐个获取：
```python
try:
    # 批量获取
    tickers = Ticker(symbols)
    prices_data = tickers.price
except:
    # 降级到逐个获取
    for symbol in symbols:
        price = get_current_price(symbol)
```

## 测试文件整理

已移动到 `tests/` 文件夹：
- test_yahooquery.py - yahooquery测试
- test_yfinance_price.py - yfinance测试
- test_yfinance_debug.py - yfinance调试
- test_price_fetch.py - 价格获取测试
- test_actual_scenario.py - 实际场景测试
- test_market_aware_pricing.py - 市场感知定价测试
- test_afterhours_cache.py - 盘后缓存测试

## 优势总结

✅ **更快**：1秒 vs 45-60秒（超时）
✅ **更稳定**：100%成功率 vs 0%
✅ **更高效**：批量获取，节省89% API调用
✅ **更灵活**：支持30秒快速刷新
✅ **向后兼容**：保留yfinance和Alpha Vantage作为备份

## 下一步优化建议

1. 监控yahooquery的速率限制
2. 如果遇到限制，可启用动态间隔调整
3. 考虑添加更多错误处理和重试逻辑
4. 定期检查yfinance是否恢复，作为备份选项
