# 备用文件说明

这个文件夹存放暂时不在主程序中使用，但将来可能需要的工具和文档。

## 📁 文件夹结构

```
备用文件/
├── README.md                              # 本说明文件
├── CHANGELOG_yahooquery.md                # yahooquery迁移记录
├── COMPREHENSIVE_SUMMARY.md               # 系统综合总结文档
├── REALTIME_PRICE_GUIDE.md                # 实时价格使用指南
├── realtime_monitor.py                    # 实时监控命令行工具
├── tests/                                 # 测试文件
│   ├── test_realtime_price.py            # 实时价格测试
│   └── test_yahooquery.py                # yahooquery数据源测试
├── tools/                                 # 工具脚本
│   └── calculate_monitoring_frequency.py  # 监控频率计算工具
└── utils/                                 # 备用工具函数
    └── 备用工具库.py                      # 实时价格相关工具函数
```

## 🔧 如何使用这些文件

### 1. 实时监控工具 (realtime_monitor.py)

独立的命令行实时价格监控程序（15-20分钟延迟）。

**使用方法：**
```bash
# 基本用法
python 备用文件/realtime_monitor.py

# 监控持仓股票，10秒刷新，详细模式
python 备用文件/realtime_monitor.py -p -i 10 -d

# 监控指定股票
python 备用文件/realtime_monitor.py AAPL TSLA NVDA
```

### 2. 备用工具函数库 (utils/备用工具库.py)

包含实时价格相关的实用函数。

**使用方法：**
```python
# 在你的代码中导入
import sys
sys.path.insert(0, '备用文件')
from utils.备用工具库 import get_realtime_quote, format_volume

# 获取实时报价
quote = get_realtime_quote('AAPL')
print(f"价格: ${quote['price']}")

# 格式化成交量
volume_str = format_volume(1500000)  # 输出: "1.50M"
```

**可用函数：**
- `get_realtime_quote(symbol)` - 获取单个股票实时报价
- `get_realtime_quotes_batch(symbols)` - 批量获取实时报价
- `get_market_state_cn(state)` - 市场状态中文转换
- `format_volume(volume)` - 格式化成交量
- `format_market_cap(market_cap)` - 格式化市值
- `is_market_open_now()` - 检查市场是否开盘

### 3. 监控频率计算工具 (tools/calculate_monitoring_frequency.py)

交互式工具，帮助计算最优的监控频率。

**使用方法：**
```bash
python 备用文件/tools/calculate_monitoring_frequency.py
```

### 4. 测试文件

**运行测试：**
```bash
# 测试实时价格功能
python 备用文件/tests/test_realtime_price.py

# 测试yahooquery数据源
python 备用文件/tests/test_yahooquery.py
```

## 📚 文档

- **COMPREHENSIVE_SUMMARY.md** - 详细的系统总结，包括：
  - yahooquery数据源迁移说明
  - 实时价格功能介绍
  - 性能对比数据
  - 已知限制和待验证项目

- **REALTIME_PRICE_GUIDE.md** - 实时价格功能使用指南

- **CHANGELOG_yahooquery.md** - 从yfinance迁移到yahooquery的变更记录

## ⚠️ 注意事项

1. **数据延迟**：Yahoo Finance免费API提供15-20分钟延迟数据，不是真正的实时数据
2. **主程序集成**：这些文件目前未集成到主程序(run.py/dashboard)中
3. **独立运行**：大部分工具需要单独运行，不会影响主程序

## 💡 何时使用

- **需要命令行监控价格**：使用 `realtime_monitor.py`
- **需要在代码中使用实时价格函数**：从 `utils/备用工具库.py` 导入
- **需要计算监控频率**：使用 `tools/calculate_monitoring_frequency.py`
- **开盘后验证功能**：运行测试文件

## 📝 最后更新

- 日期：2026-01-05
- 版本：1.0
- 状态：已整理，随时可用
