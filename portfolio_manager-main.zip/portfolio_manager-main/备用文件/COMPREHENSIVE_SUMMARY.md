# 投资组合管理系统 - 数据源迁移和实时价格功能总结

**更新日期**: 2026-01-03
**状态**: 休市时完成，待开盘验证

---

## 📋 本次更新内容总览

### 1. 数据源迁移：yfinance → yahooquery
- **原因**: yfinance被ban，所有请求超时失败
- **解决**: 切换到yahooquery，性能提升45-60倍
- **状态**: ✅ 已完成并测试（休市状态下）

### 2. 实时价格功能
- **功能**: 盘中实时价格监控（15-20分钟延迟）
- **状态**: ✅ 已完成代码，⏳ 待开盘验证

### 3. 配置优化
- **检查间隔**: 300秒 → 30秒
- **批量获取**: 启用（9个股票1次API调用）
- **状态**: ✅ 已完成

---

## 🎯 完整功能清单

### A. 核心数据获取功能

#### 1. 价格获取（utils/data_fetcher.py）

**主要函数**:
```python
# 单个股票价格
get_current_price(symbol)
  - 使用: yahooquery (主)
  - 备份: yfinance, Alpha Vantage
  - 响应时间: ~1秒
  - 重试: 2次，延迟1秒

# 批量获取价格（推荐）
batch_get_prices(symbols, use_batch=True, force_refresh=False)
  - 批量获取: 9个股票 = 1次API调用
  - 盘中: 获取实时价格
  - 盘后: 优先使用今日缓存
  - 响应时间: ~2秒（9个股票）
```

**功能特性**:
- ✅ 盘中/盘后智能切换
- ✅ 今日收盘价缓存（盘后节省96% API调用）
- ✅ 批量获取优化（节省89% API调用）
- ✅ 自动降级（批量失败→逐个获取）
- ✅ 市场状态检测

**支持的价格类型**:
- `regularMarketPrice` - 盘中价格
- `postMarketPrice` - 盘后价格
- `preMarketPrice` - 盘前价格

#### 2. 实时报价（utils/realtime_price.py）

**主要函数**:
```python
# 单个股票实时报价
get_realtime_quote(symbol)
  返回: {
    'symbol': 股票代码,
    'price': 当前价格,
    'change': 涨跌额,
    'change_percent': 涨跌幅,
    'volume': 成交量,
    'day_high': 日内高,
    'day_low': 日内低,
    'bid': 买价,
    'ask': 卖价,
    'market_state': 市场状态,
    'market_cap': 市值,
    ...
  }

# 批量获取实时报价
get_realtime_quotes_batch(symbols)
  返回: DataFrame包含所有股票的实时信息

# 检查市场状态
is_market_open_now()
  返回: (是否开盘, 市场状态)
```

**提供的数据**:
- ✅ 当前价格（根据市场状态）
- ✅ 涨跌额/涨跌幅
- ✅ 买价/卖价（盘中）
- ✅ 日内高/低
- ✅ 开盘价/昨收价
- ✅ 成交量/平均成交量
- ✅ 市值
- ✅ 市场状态

### B. 实时监控程序（realtime_monitor.py）

**命令行工具**:
```bash
# 基本用法
python realtime_monitor.py                    # 默认股票，30秒刷新
python realtime_monitor.py MU PLTR NVDA       # 指定股票
python realtime_monitor.py -i 10              # 10秒刷新
python realtime_monitor.py -d                 # 详细模式（买卖价、日高低）
python realtime_monitor.py -p                 # 使用持仓股票
python realtime_monitor.py -p -i 10 -d        # 组合参数
```

**显示界面**:
```
基本模式:
股票   状态  价格      涨跌额    涨跌幅    成交量(M)
MU    盘中  $315.42  +$30.03  +10.52%  41.88      ↑

详细模式 (-d):
股票  状态  价格    涨跌额  涨跌幅  买价    卖价    成交量  日高    日低
MU   盘中  $315.42 +$30.03 +10.52% $315.40 $315.45 41.88  $315.60 $295.02 ↑
```

**功能特性**:
- ✅ 自动刷新（可配置间隔）
- ✅ 清屏显示（类似top命令）
- ✅ 涨跌颜色标识（↑↓→）
- ✅ 统计汇总（上涨/下跌数量）
- ✅ 支持Ctrl+C停止
- ✅ 批量获取（高性能）

### C. 预警监控系统（decision/alert_system.py）

**集成特性**:
- ✅ 自动监控持仓股票 + 预警股票
- ✅ 使用yahooquery批量获取价格
- ✅ 30秒检查间隔（可配置）
- ✅ 盘后使用缓存（减少API调用）
- ✅ 动态间隔调整（可选，默认禁用）

**配置（config.py）**:
```python
ALERT_MONITORING_CONFIG = {
    'check_interval': 30,                    # 30秒检查
    'enable_dynamic_interval': False,        # 禁用动态间隔
    'target_requests_per_hour': 120,         # 120次/小时
    'min_check_interval': 30,                # 最小30秒
    'max_check_interval': 300,               # 最大5分钟
}
```

### D. 市场状态检测（utils/market_hours.py）

**功能**:
- ✅ 检测美股市场开盘/休市
- ✅ 盘前/盘中/盘后识别
- ✅ 时区转换（美东时间）
- ✅ 节假日检测

**市场状态**:
| 状态 | 英文 | 时间(ET) | 说明 |
|-----|------|---------|------|
| 盘前 | PRE | 04:00-09:30 | 盘前交易 |
| 盘中 | REGULAR | 09:30-16:00 | 正常交易 |
| 盘后 | POST | 16:00-20:00 | 盘后交易 |
| 休市 | CLOSED | 其他时间 | 周末/节假日 |

---

## 📊 性能对比

### 数据源性能

| 指标 | yfinance (旧) | yahooquery (新) | 提升 |
|-----|--------------|----------------|------|
| 单股票响应 | 45-60秒（超时） | ~1秒 | 45-60倍 ✅ |
| 4股票批量 | 超时失败 | 1.33秒 | 成功 ✅ |
| 8股票批量 | 超时失败 | ~2秒 | 成功 ✅ |
| 成功率 | 0% | 100% | ✅ |

### API调用量优化

#### 批量获取优化
```
旧方法（逐个）: 9个股票 = 9次API调用
新方法（批量）: 9个股票 = 1次API调用
节省: 89% ↓
```

#### 盘后缓存优化
```
传统方式（无缓存）:
  - 盘后17.5小时
  - 每2.2分钟检查一次
  - 9股票 × 27次 = 243次API调用

智能缓存方式:
  - 第1次: 获取收盘价（1次API调用）
  - 第2-27次: 使用缓存（0次API调用）
  - 总计: 1次API调用

节省: 242次/天 (99.6% ↓)
```

#### 每小时API调用量

| 配置 | 旧方案 | 新方案 | 节省 |
|-----|-------|-------|------|
| 检查间隔 | 300秒 | 30秒 | - |
| 9个股票/次调用 | 9次 | 1次 | 89% |
| 每小时调用 | 108次 | 120次 | - |
| 盘后调用 | 243次 | 1次 | 99.6% |

---

## ⚠️ 已知缺陷和限制

### 1. 数据延迟问题

**问题描述**:
- Yahoo Finance免费API提供的是**15-20分钟延迟数据**
- 不是真正的tick-by-tick实时数据

**影响**:
- ❌ 不适合高频交易
- ❌ 不适合需要秒级精度的场景
- ✅ 适合日常监控
- ✅ 适合趋势分析
- ✅ 适合价格预警

**状态**: 这是免费数据源的固有限制，无法修复

**解决方案**:
- 付费数据源: IEX Cloud, Polygon.io
- 券商API: TD Ameritrade, Interactive Brokers
- WebSocket实时流: 需要订阅服务

### 2. 休市时的数据限制

**问题描述**:
- 休市时买卖价（bid/ask）显示为 `None` 或 `N/A`
- 只有盘中交易时才有买卖价

**影响**:
- ⚠️ 详细模式 (`-d`) 在休市时部分字段为空
- ⚠️ 价差（spread）无法计算

**状态**: 这是正常行为，不是bug

**测试时间**: 休市期间测试，无法验证盘中买卖价功能

### 3. yahooquery 稳定性

**问题描述**:
- yahooquery依赖Yahoo Finance API
- Yahoo可能随时更改API或限制访问
- 未知的速率限制

**潜在风险**:
- ⚠️ API结构变化导致解析失败
- ⚠️ 触发未知的速率限制
- ⚠️ 某些股票数据不可用

**当前状态**:
- ✅ 休市测试：全部成功
- ⏳ 盘中测试：待验证

**缓解措施**:
- ✅ 已实现降级机制（批量→逐个）
- ✅ 保留yfinance作为备份
- ✅ 保留Alpha Vantage作为备份
- ✅ 错误重试机制

### 4. 盘中实时性未验证

**问题描述**:
- 所有代码在**休市时**完成和测试
- 盘中行为（实时价格、买卖价、成交量更新）未实际验证

**需要验证的功能**:
```
⏳ 实时价格更新频率
⏳ 买卖价（bid/ask）准确性
⏳ 成交量实时更新
⏳ 市场状态切换（PRE→REGULAR→POST）
⏳ 价格变化检测
⏳ 预警触发的实时性
⏳ 30秒刷新是否流畅
⏳ API速率限制的实际阈值
```

**开盘后必须测试**:
1. 运行 `python realtime_monitor.py -p -i 10 -d`
2. 观察价格是否实时更新
3. 检查买卖价是否显示
4. 验证成交量变化
5. 测试30秒间隔是否合适
6. 检查是否触发速率限制

### 5. 市场状态检测精度

**问题描述**:
- 市场状态依赖yahooquery返回的 `marketState` 字段
- 未验证状态转换的准确性

**潜在问题**:
- ⚠️ 状态转换延迟（如9:30开盘时何时从PRE变为REGULAR）
- ⚠️ 节假日识别可能不准确
- ⚠️ 时区转换可能有误差

**需要验证**:
- 开盘前（9:00-9:30）状态
- 开盘瞬间（9:30）状态切换
- 收盘瞬间（16:00）状态切换
- 盘后交易（16:00-20:00）状态

### 6. 错误处理不够完善

**已知问题**:
```python
# utils/realtime_price.py
try:
    stock = Ticker(symbol)
    price_data = stock.price
    # 如果price_data格式异常，可能导致KeyError
except Exception as e:
    print(f"获取失败: {e}")  # 错误信息不够详细
    return None
```

**缺陷**:
- ❌ 捕获所有异常，不够精细
- ❌ 错误日志不够详细
- ❌ 没有区分网络错误、数据错误、API限制等

**需要改进**:
- 增加详细的异常分类
- 添加日志记录（logging）
- 区分可恢复错误和致命错误

### 7. 配置灵活性

**问题描述**:
- 检查间隔固定为30秒（config.py）
- 禁用了动态间隔调整

**潜在问题**:
- ⚠️ 30秒可能太快（触发限制）
- ⚠️ 30秒可能太慢（错过价格变化）
- ⚠️ 盘后仍然30秒刷新（浪费）

**需要验证**:
- 30秒间隔是否会触发速率限制
- 是否需要区分盘中/盘后间隔
- 是否需要重新启用动态间隔

### 8. 缓存机制的时区问题

**潜在问题**:
```python
# utils/data_fetcher.py 第213行
eastern = pytz.timezone('America/New_York')
now_et = datetime.now(eastern)
today_date = now_et.date()

# 检查缓存是否是今天的
if cached_date == today_date:
    # 使用缓存
```

**风险**:
- ⚠️ 在中国时间晚上8点（美东早上8点）时，可能出现日期判断错误
- ⚠️ 夏令时切换时可能有问题

**需要验证**:
- 在不同时区测试日期判断
- 夏令时切换期间测试

### 9. 批量获取的失败降级

**当前实现**:
```python
# utils/data_fetcher.py
try:
    # 批量获取
    tickers = Ticker(symbols)
    prices_data = tickers.price
except:
    # 降级到逐个获取
    use_batch = False
```

**问题**:
- ⚠️ 降级后逐个获取很慢（9个股票 × 1秒 = 9秒+）
- ⚠️ 没有部分成功处理（如9个股票，7个成功，2个失败）

**需要改进**:
- 批量获取后检查哪些失败，只重新获取失败的
- 设置超时时间
- 记录失败原因

### 10. 测试覆盖不足

**已测试**:
- ✅ 休市状态下获取收盘价
- ✅ 批量获取功能
- ✅ 数据解析正确性

**未测试**:
- ❌ 盘中实时价格
- ❌ 买卖价准确性
- ❌ 成交量实时性
- ❌ 市场状态切换
- ❌ 速率限制触发
- ❌ 长时间运行稳定性
- ❌ 异常情况处理
- ❌ 网络中断恢复

---

## 🔧 待开盘后修改的项目

### 高优先级（必须验证）

#### 1. 验证实时价格功能
```bash
# 开盘后立即运行
python realtime_monitor.py -p -i 10 -d

# 观察：
# - 价格是否实时更新？
# - 买卖价是否显示？
# - 成交量是否变化？
# - 是否有错误？
```

**如果发现问题**:
- 检查 `marketState` 是否正确
- 检查价格字段是否存在
- 调整重试逻辑

#### 2. 测试速率限制
```bash
# 运行5-10分钟，观察是否触发限制
python realtime_monitor.py -p -i 30

# 如果触发限制（错误429或数据获取失败）:
# - 增加间隔到60秒
# - 或启用动态间隔调整
```

**修改位置**: `config.py` 第71行
```python
# 如果30秒太快
'check_interval': int(os.getenv('ALERT_CHECK_INTERVAL', '60')),  # 改为60秒
```

#### 3. 验证市场状态切换
```bash
# 在关键时间点测试：
# 9:20 AM ET - 盘前
# 9:30 AM ET - 开盘瞬间
# 12:00 PM ET - 盘中
# 4:00 PM ET - 收盘瞬间
# 5:00 PM ET - 盘后

python tests/test_realtime_price.py
```

**如果状态不准确**:
- 检查时区设置
- 验证 `marketState` 字段
- 考虑添加手动状态判断

### 中优先级（根据情况修改）

#### 4. 优化错误处理

**当前代码** (`utils/realtime_price.py`):
```python
except Exception as e:
    print(f"获取{symbol}实时报价失败: {e}")
    return None
```

**改进为**:
```python
import logging

logger = logging.getLogger(__name__)

try:
    # ...
except requests.exceptions.Timeout:
    logger.error(f"{symbol}: 请求超时")
    return None
except requests.exceptions.ConnectionError:
    logger.error(f"{symbol}: 网络连接失败")
    return None
except KeyError as e:
    logger.error(f"{symbol}: 数据字段缺失 - {e}")
    return None
except Exception as e:
    logger.error(f"{symbol}: 未知错误 - {e}")
    return None
```

#### 5. 添加速率限制检测

**修改** `utils/data_fetcher.py`:
```python
import time

# 全局变量跟踪API调用
_api_call_count = 0
_api_call_reset_time = time.time()

def batch_get_prices(symbols, ...):
    global _api_call_count, _api_call_reset_time

    # 每小时重置
    if time.time() - _api_call_reset_time > 3600:
        _api_call_count = 0
        _api_call_reset_time = time.time()

    # 检查是否接近限制
    if _api_call_count > 100:  # yahooquery限制未知，保守估计
        print(f"⚠️ 接近速率限制 ({_api_call_count}次/小时)，等待...")
        time.sleep(10)

    # 获取价格
    try:
        tickers = Ticker(symbols)
        prices_data = tickers.price
        _api_call_count += 1  # 批量算1次
    except:
        pass
```

#### 6. 改进批量获取降级

**当前**: 全部失败才降级
**改进**: 部分失败只重新获取失败的

```python
def batch_get_prices(symbols, ...):
    # 批量获取
    tickers = Ticker(symbols)
    prices_data = tickers.price

    prices = {}
    failed_symbols = []

    for symbol in symbols:
        if symbol in prices_data and isinstance(prices_data[symbol], dict):
            # 解析价格
            price = ...
            if price:
                prices[symbol] = price
            else:
                failed_symbols.append(symbol)
        else:
            failed_symbols.append(symbol)

    # 只重新获取失败的
    if failed_symbols:
        print(f"⚠️ {len(failed_symbols)} 个股票获取失败，重试...")
        for symbol in failed_symbols:
            price = get_current_price(symbol)  # 逐个重试
            if price:
                prices[symbol] = price

    return prices
```

#### 7. 区分盘中/盘后检查间隔

**修改** `decision/alert_system.py`:
```python
def monitor_loop():
    while self.monitoring:
        # 检查市场状态
        is_open, market_state = is_market_open_now()

        # 根据市场状态调整间隔
        if market_state == 'REGULAR':
            interval = 30  # 盘中30秒
        elif market_state in ['PRE', 'POST']:
            interval = 60  # 盘前/盘后1分钟
        else:
            interval = 300  # 休市5分钟（或不检查）

        # 获取价格...

        time.sleep(interval)
```

### 低优先级（可选优化）

#### 8. 添加日志记录

```python
# 在主要模块添加logging
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('portfolio_monitor.log'),
        logging.StreamHandler()
    ]
)
```

#### 9. 添加价格历史缓存

```python
# 缓存日内价格历史，用于绘图
price_history = {}  # {symbol: [(time, price), ...]}

def track_price_history(symbol, price):
    if symbol not in price_history:
        price_history[symbol] = []

    price_history[symbol].append((datetime.now(), price))

    # 只保留今天的数据
    cutoff = datetime.now().replace(hour=0, minute=0, second=0)
    price_history[symbol] = [
        (t, p) for t, p in price_history[symbol] if t >= cutoff
    ]
```

#### 10. WebSocket实时推送（高级）

```python
# 如果需要真正的实时数据，考虑WebSocket
# 需要付费数据源或券商API

# 示例：使用polygon.io WebSocket
import websocket
import json

def on_message(ws, message):
    data = json.loads(message)
    # 处理实时tick数据
    symbol = data['sym']
    price = data['p']
    # 触发预警检查
    check_alerts({symbol: price})

def on_error(ws, error):
    print(f"WebSocket错误: {error}")

def on_close(ws):
    print("WebSocket连接关闭")

def on_open(ws):
    # 订阅股票
    ws.send(json.dumps({
        'action': 'subscribe',
        'params': 'T.MU,T.PLTR'  # 订阅股票
    }))

# 连接WebSocket
ws = websocket.WebSocketApp(
    "wss://socket.polygon.io/stocks",
    on_message=on_message,
    on_error=on_error,
    on_close=on_close
)
ws.on_open = on_open
ws.run_forever()
```

---

## 📂 文件清单

### 核心文件（已修改）

| 文件 | 状态 | 主要改动 |
|-----|------|---------|
| `utils/data_fetcher.py` | ✅ 已修改 | yahooquery替代yfinance，批量获取优化 |
| `config.py` | ✅ 已修改 | 30秒间隔，禁用动态间隔 |
| `decision/alert_system.py` | ✅ 已修改 | 集成新的批量获取 |

### 新增文件

| 文件 | 用途 |
|-----|------|
| `utils/realtime_price.py` | 实时价格工具模块 |
| `realtime_monitor.py` | 实时监控主程序 |
| `tests/test_yahooquery.py` | yahooquery测试 |
| `tests/test_realtime_price.py` | 实时价格测试 |
| `tests/test_realtime_monitor_once.py` | 监控程序测试 |
| `CHANGELOG_yahooquery.md` | 数据源迁移记录 |
| `REALTIME_PRICE_GUIDE.md` | 实时价格使用指南 |
| `COMPREHENSIVE_SUMMARY.md` | 本文档 |

### 测试文件（已整理）

已移动到 `tests/` 文件夹：
- test_dynamic_interval.py
- test_yfinance_price.py
- test_yfinance_debug.py
- test_actual_scenario.py
- test_market_aware_pricing.py
- test_afterhours_cache.py
- test_price_fetch.py
- test_yahooquery.py
- test_realtime_price.py
- test_realtime_monitor_once.py

---

## 🚀 开盘后验证清单

### 第一步：基本功能验证（9:30-9:45 AM ET）

```bash
# 1. 测试实时价格获取
python tests/test_realtime_price.py

# 观察：
# ✓ 价格是否显示？
# ✓ marketState 是否为 'REGULAR'？
# ✓ bid/ask 是否有值？
# ✓ 成交量是否 > 0？
```

```bash
# 2. 启动监控程序（观察2-3分钟）
python realtime_monitor.py -p -i 30 -d

# 观察：
# ✓ 价格是否每30秒更新？
# ✓ 买卖价是否显示？
# ✓ 是否有错误提示？
# ✓ 涨跌幅是否变化？
```

```bash
# 3. 测试批量获取
python tests/test_price_fetch.py

# 观察：
# ✓ 批量获取是否成功？
# ✓ 所有股票都获取到？
# ✓ 响应时间是否 < 5秒？
```

### 第二步：预警系统验证（如果有预警）

```bash
# 启动Streamlit Dashboard
streamlit run ui/dashboard.py

# 在预警页面：
# ✓ 检查价格是否实时更新
# ✓ 设置一个接近当前价的预警
# ✓ 等待触发，验证通知是否发送
```

### 第三步：压力测试（运行15-30分钟）

```bash
# 持续运行监控程序
python realtime_monitor.py -p -i 30

# 监控：
# ✓ 是否出现错误？
# ✓ 是否触发速率限制？
# ✓ 内存使用是否正常？
# ✓ 价格更新是否稳定？
```

### 第四步：不同市场状态验证

| 时间(ET) | 状态 | 验证项 |
|---------|------|-------|
| 9:20 AM | 盘前 | marketState='PRE'，有preMarketPrice |
| 9:30 AM | 开盘 | 状态切换到'REGULAR' |
| 12:00 PM | 盘中 | regularMarketPrice更新 |
| 4:00 PM | 收盘 | 状态切换到'POST' |
| 5:00 PM | 盘后 | postMarketPrice显示 |

### 第五步：根据结果调整

#### 如果价格不更新
```python
# 检查 utils/realtime_price.py
# 打印调试信息
print(f"Debug: price_data = {price_data}")
print(f"Debug: market_state = {market_state}")
```

#### 如果触发速率限制
```python
# 修改 config.py
'check_interval': 60,  # 改为60秒
```

#### 如果买卖价为空
```python
# 可能盘中也没有bid/ask
# 检查是否是yahooquery的限制
# 考虑降级显示或标记为N/A
```

---

## 📝 开盘后修改模板

### 创建问题报告
```markdown
## 开盘测试问题报告

**测试时间**: 2026-01-XX 9:30-10:00 AM ET
**测试股票**: MU, PLTR, NVDA, TSLA (你的持仓)

### 问题1: [问题描述]
**现象**:
**影响**:
**复现步骤**:
**错误日志**:
**建议修复**:

### 问题2: ...
```

### 修改优先级判断
```
P0 (致命): 完全无法获取价格、系统崩溃
P1 (严重): 价格不更新、速率限制频繁触发
P2 (重要): 买卖价缺失、延迟过大
P3 (一般): 显示格式、小的功能缺陷
P4 (优化): 性能优化、代码改进
```

---

## 🎯 总结

### 已完成
✅ yahooquery数据源迁移
✅ 批量获取优化
✅ 盘后缓存机制
✅ 实时价格功能代码
✅ 实时监控程序
✅ 30秒检查间隔配置
✅ 测试文件整理

### 待验证（开盘后）
⏳ 盘中实时价格准确性
⏳ 买卖价显示
⏳ 速率限制阈值
⏳ 市场状态切换
⏳ 长时间运行稳定性
⏳ 预警触发实时性

### 已知限制
⚠️ 15-20分钟延迟（免费数据）
⚠️ 休市时买卖价为空
⚠️ yahooquery速率限制未知
⚠️ 部分功能未实际测试

### 推荐的开盘后操作
1. **立即测试** `python realtime_monitor.py -p -i 30 -d`（观察5分钟）
2. **检查错误**：是否有异常、速率限制
3. **验证数据**：价格、买卖价、成交量
4. **调整配置**：根据实际情况调整间隔
5. **记录问题**：准备给Claude的问题清单

---

**开盘时给Claude的指令模板**：

```
我已经阅读了 COMPREHENSIVE_SUMMARY.md。

现在是开盘时间（YYYY-MM-DD HH:MM ET），我运行了测试：

python realtime_monitor.py -p -i 30 -d

发现以下问题：
1. [问题描述]
2. [问题描述]
3. [问题描述]

请帮我修复这些问题。

附加信息：
- 错误日志：[粘贴错误]
- 截图：[如果有]
- 观察到的现象：[描述]
```

---

**文档版本**: 1.0
**创建时间**: 2026-01-03 14:30 (休市)
**下次更新**: 开盘后验证完成
