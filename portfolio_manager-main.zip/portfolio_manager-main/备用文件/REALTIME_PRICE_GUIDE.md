# 实时价格功能使用指南

## 功能概述

使用 yahooquery 获取股票实时价格（或15-20分钟延迟价格），支持：
- ✅ 盘中实时价格
- ✅ 盘前/盘后价格
- ✅ 买卖价差（Bid/Ask）
- ✅ 实时成交量
- ✅ 日内高低价
- ✅ 批量获取（高性能）
- ✅ 持续监控（自动刷新）

## 数据延迟说明

| 数据类型 | 延迟时间 | 说明 |
|---------|---------|------|
| 收盘价 | 实时 | 市场收盘后即可获取 |
| 盘中价格 | 0-20分钟 | 免费数据源有延迟，实际延迟取决于yahooquery |
| 买卖价 | 0-20分钟 | 盘中交易时可用 |
| 成交量 | 0-20分钟 | 实时更新 |

**注意**：Yahoo Finance 免费API提供的是延迟数据，不是真正的tick-by-tick实时数据。对于大多数个人投资者来说，15-20分钟的延迟足够使用。

## 快速开始

### 1. 实时监控程序（推荐）

```bash
# 使用默认股票列表，30秒刷新
python realtime_monitor.py

# 监控指定股票
python realtime_monitor.py MU PLTR NVDA TSLA

# 10秒刷新间隔
python realtime_monitor.py -i 10

# 显示详细信息（买卖价、日高低）
python realtime_monitor.py -d

# 使用数据库中的持仓股票
python realtime_monitor.py -p

# 组合使用
python realtime_monitor.py -p -i 10 -d
```

### 2. 在代码中使用

#### 获取单个股票实时报价

```python
from utils.realtime_price import get_realtime_quote

# 获取MU的实时报价
quote = get_realtime_quote('MU')

print(f"股票: {quote['symbol']}")
print(f"价格: ${quote['price']:.2f}")
print(f"涨跌: {quote['change']:.2f} ({quote['change_percent']:.2f}%)")
print(f"市场状态: {quote['market_state']}")
print(f"成交量: {quote['volume']:,}")
print(f"买价: ${quote['bid']:.2f}")
print(f"卖价: ${quote['ask']:.2f}")
```

#### 批量获取多个股票

```python
from utils.realtime_price import get_realtime_quotes_batch

# 批量获取
symbols = ['MU', 'PLTR', 'NVDA', 'TSLA']
quotes_df = get_realtime_quotes_batch(symbols)

# 显示结果
print(quotes_df[['股票代码', '当前价格', '涨跌额', '涨跌幅(%)', '市场状态']])
```

#### 检查市场是否开盘

```python
from utils.realtime_price import is_market_open_now

is_open, market_state = is_market_open_now()
print(f"市场开盘: {is_open}")
print(f"市场状态: {market_state}")
```

### 3. 集成到Dashboard

在 `ui/dashboard.py` 中添加实时价格显示：

```python
import streamlit as st
from utils.realtime_price import get_realtime_quotes_batch, get_market_state_cn

# 在侧边栏显示实时价格
st.sidebar.header("实时价格")

# 获取持仓股票
symbols = stocks['股票代码'].unique().tolist()

# 批量获取实时报价
quotes_df = get_realtime_quotes_batch(symbols)

# 显示
if not quotes_df.empty:
    for _, row in quotes_df.iterrows():
        symbol = row['股票代码']
        price = row['当前价格']
        change = row['涨跌额']
        change_pct = row['涨跌幅(%)']

        # 涨跌颜色
        color = "green" if change > 0 else "red" if change < 0 else "gray"

        st.sidebar.markdown(
            f"**{symbol}**: ${price:.2f} "
            f"<span style='color:{color}'>{change:+.2f} ({change_pct:+.2f}%)</span>",
            unsafe_allow_html=True
        )
```

## 命令行参数说明

### realtime_monitor.py 参数

| 参数 | 说明 | 示例 |
|-----|------|------|
| `symbols` | 股票代码列表 | `MU PLTR NVDA` |
| `-i, --interval` | 刷新间隔（秒） | `-i 10` |
| `-d, --detail` | 显示详细信息 | `-d` |
| `-p, --portfolio` | 使用持仓股票 | `-p` |

## 显示界面说明

### 基本视图

```
股票       状态       价格         涨跌额        涨跌幅        成交量(M)
MU       盘中       $315.42    +$30.03    +10.52%   41.88        ↑
PLTR     盘中       $167.86    -$9.89     -5.56%    45.14        ↓
```

### 详细视图（-d 参数）

```
股票   状态   价格     涨跌额   涨跌幅   买价     卖价     成交量(M)  日高     日低
MU    盘中   $315.42  +$30.03  +10.52%  $315.40  $315.45  41.88    $315.60  $295.02  ↑
```

## 市场状态说明

| 英文状态 | 中文 | 说明 | 显示价格 |
|---------|------|------|---------|
| REGULAR | 盘中 | 正常交易时间 | regularMarketPrice（实时） |
| PRE | 盘前 | 盘前交易（4:00-9:30 ET） | preMarketPrice |
| POST | 盘后 | 盘后交易（16:00-20:00 ET） | postMarketPrice |
| CLOSED | 休市 | 周末或节假日 | regularMarketPrice（收盘价） |
| PREPRE | 准备中 | 开盘前准备 | regularMarketPrice（昨收盘） |

## 数据字段说明

| 字段 | 说明 | 类型 |
|-----|------|------|
| symbol | 股票代码 | str |
| price | 当前价格 | float |
| change | 涨跌额 | float |
| change_percent | 涨跌幅(%) | float |
| volume | 成交量 | int |
| day_high | 日内最高价 | float |
| day_low | 日内最低价 | float |
| open | 开盘价 | float |
| prev_close | 昨收盘价 | float |
| bid | 买价 | float |
| ask | 卖价 | float |
| market_state | 市场状态 | str |
| market_cap | 市值 | int |
| avg_volume | 平均成交量 | int |

## 性能优化

### 批量获取 vs 逐个获取

```python
# ❌ 慢：逐个获取（8个股票需要8次API调用，耗时8-16秒）
for symbol in symbols:
    quote = get_realtime_quote(symbol)
    time.sleep(1)

# ✅ 快：批量获取（8个股票只需1次API调用，耗时2秒）
quotes_df = get_realtime_quotes_batch(symbols)
```

### 刷新间隔建议

| 用途 | 建议间隔 | 说明 |
|-----|---------|------|
| 日常监控 | 30-60秒 | 平衡实时性和API调用 |
| 活跃交易 | 10-15秒 | 较快的价格更新 |
| 盘后监控 | 60-300秒 | 价格不变化，降低频率 |

## 测试文件

| 文件 | 说明 |
|-----|------|
| `tests/test_realtime_price.py` | 测试实时价格功能 |
| `tests/test_realtime_monitor_once.py` | 测试监控程序（单次） |

运行测试：
```bash
python tests/test_realtime_price.py
python tests/test_realtime_monitor_once.py
```

## 故障排除

### 1. 获取价格失败

**问题**：返回 None 或空数据

**解决**：
- 检查网络连接
- 确认股票代码正确（使用美股代码，如 MU 不是 MU.US）
- yahooquery 可能暂时不可用，等待几分钟重试

### 2. 买卖价显示 N/A

**原因**：休市时没有买卖价

**说明**：只有在盘中交易时才有买卖价（bid/ask），休市、盘前、盘后可能显示 N/A

### 3. 价格延迟

**说明**：Yahoo Finance 免费数据有15-20分钟延迟

**替代方案**：
- 使用付费数据源（如 IEX Cloud、Alpha Vantage）
- 券商API（如 TD Ameritrade、Interactive Brokers）
- 实时数据订阅服务

## 与现有功能集成

### 1. 更新 data_fetcher.py

已经完成，`batch_get_prices()` 现在使用 yahooquery 批量获取

### 2. 更新预警系统

预警系统会自动使用新的价格获取方式：
- 盘中：获取实时价格，触发预警
- 盘后：使用缓存的收盘价，减少API调用

### 3. Dashboard 实时价格

可以在 Dashboard 中添加：
- 侧边栏：实时价格Ticker
- 主页面：价格走势图
- 预警页面：价格监控面板

## 未来优化方向

1. **WebSocket 实时推送**
   - 使用 WebSocket 获取真正的实时数据
   - 降低API调用频率
   - 提升响应速度

2. **历史数据缓存**
   - 缓存日内价格历史
   - 绘制分时图
   - 分析日内波动

3. **价格预警增强**
   - 基于实时价格的快速预警
   - 价格突破检测
   - 异常波动提醒

4. **多数据源fallback**
   - yahooquery 失败时自动切换到 yfinance
   - yfinance 失败时切换到 Alpha Vantage
   - 提高系统稳定性

## 总结

✅ **已实现**：
- 实时价格获取（yahooquery）
- 批量获取优化
- 持续监控程序
- 盘中/盘后智能切换
- 详细市场信息

🎯 **下一步**：
- 集成到Dashboard
- 添加价格图表
- 增强预警系统
- WebSocket 实时推送（可选）
