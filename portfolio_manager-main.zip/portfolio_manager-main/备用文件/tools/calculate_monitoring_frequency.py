"""
监控频率计算工具

帮助用户根据股票数量和API限制，计算最优的监控频率
"""

import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32' and hasattr(sys.stdout, 'buffer'):
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except:
        pass

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import calculate_dynamic_interval, ALERT_MONITORING_CONFIG


def format_time(seconds):
    """格式化时间显示"""
    if seconds < 60:
        return f"{seconds}秒"
    else:
        minutes = seconds / 60
        if minutes < 60:
            return f"{minutes:.1f}分钟"
        else:
            hours = minutes / 60
            return f"{hours:.1f}小时"


def calculate_frequency_from_stocks(stock_count, target_calls_per_hour=None):
    """
    根据股票数量计算监控频率

    Args:
        stock_count: 股票数量
        target_calls_per_hour: 目标每小时调用次数（可选，默认使用配置值）

    Returns:
        dict: 包含间隔、调用量等信息
    """
    if target_calls_per_hour is None:
        target_calls_per_hour = ALERT_MONITORING_CONFIG['target_requests_per_hour']

    if stock_count == 0:
        return None

    interval = calculate_dynamic_interval(stock_count)
    interval_min = interval / 60
    calls_per_hour = int(3600 / interval) * stock_count if interval > 0 else 0
    calls_per_day = calls_per_hour * 24

    # 安全性评估
    if calls_per_hour <= target_calls_per_hour:
        safety = "✅ 安全"
        safety_level = "high"
    elif calls_per_hour <= 300:
        safety = "⚠️ 基本安全"
        safety_level = "medium"
    elif calls_per_hour <= 360:
        safety = "⚠️ 接近限制"
        safety_level = "low"
    else:
        safety = "❌ 超出限制"
        safety_level = "danger"

    return {
        'stock_count': stock_count,
        'interval_seconds': interval,
        'interval_minutes': interval_min,
        'interval_formatted': format_time(interval),
        'calls_per_hour': calls_per_hour,
        'calls_per_day': calls_per_day,
        'safety': safety,
        'safety_level': safety_level,
        'target_calls_per_hour': target_calls_per_hour,
    }


def calculate_max_stocks_for_frequency(desired_interval_minutes, target_calls_per_hour=None):
    """
    根据期望的监控频率计算最多能监控多少股票

    Args:
        desired_interval_minutes: 期望的检查间隔（分钟）
        target_calls_per_hour: 目标每小时调用次数（可选）

    Returns:
        dict: 包含最大股票数等信息
    """
    if target_calls_per_hour is None:
        target_calls_per_hour = ALERT_MONITORING_CONFIG['target_requests_per_hour']

    desired_interval_seconds = desired_interval_minutes * 60

    # 计算最大股票数
    # interval = 3600 * stock_count / target_calls_per_hour
    # stock_count = interval * target_calls_per_hour / 3600
    max_stocks = int((desired_interval_seconds * target_calls_per_hour) / 3600)

    if max_stocks <= 0:
        max_stocks = 1

    # 验证计算
    actual_interval = (3600 * max_stocks) / target_calls_per_hour
    actual_calls = int(3600 / actual_interval) * max_stocks if actual_interval > 0 else 0

    return {
        'desired_interval_minutes': desired_interval_minutes,
        'desired_interval_seconds': desired_interval_seconds,
        'max_stocks': max_stocks,
        'actual_interval_seconds': int(actual_interval),
        'actual_interval_minutes': actual_interval / 60,
        'actual_interval_formatted': format_time(int(actual_interval)),
        'actual_calls_per_hour': actual_calls,
        'target_calls_per_hour': target_calls_per_hour,
    }


def print_interactive_calculator():
    """交互式计算器"""
    print("=" * 70)
    print("监控频率计算工具")
    print("=" * 70)
    print()
    print("当前配置:")
    print(f"  目标每小时调用: {ALERT_MONITORING_CONFIG['target_requests_per_hour']} 次")
    print(f"  最小检查间隔: {ALERT_MONITORING_CONFIG['min_check_interval']} 秒")
    print(f"  最大检查间隔: {ALERT_MONITORING_CONFIG['max_check_interval']} 秒")
    print()
    print("选择计算方式:")
    print("  1. 根据股票数量计算监控频率")
    print("  2. 根据期望频率计算最多能监控多少股票")
    print("  3. 查看常见场景对比")
    print("  4. 退出")
    print()

    while True:
        choice = input("请选择 (1-4): ").strip()

        if choice == '1':
            print()
            try:
                stock_count = int(input("请输入股票数量: "))
                result = calculate_frequency_from_stocks(stock_count)

                if result:
                    print()
                    print("-" * 70)
                    print(f"计算结果（{stock_count} 个股票）:")
                    print("-" * 70)
                    print(f"  检查间隔: {result['interval_formatted']} ({result['interval_seconds']} 秒)")
                    print(f"  每小时调用: {result['calls_per_hour']} 次")
                    print(f"  每天调用: {result['calls_per_day']} 次")
                    print(f"  安全性: {result['safety']}")
                    print("-" * 70)
            except ValueError:
                print("❌ 请输入有效的数字")
            print()

        elif choice == '2':
            print()
            try:
                desired_minutes = float(input("请输入期望的检查间隔（分钟）: "))
                result = calculate_max_stocks_for_frequency(desired_minutes)

                print()
                print("-" * 70)
                print(f"计算结果（间隔 {desired_minutes} 分钟）:")
                print("-" * 70)
                print(f"  最多可监控: {result['max_stocks']} 个股票")
                print(f"  实际间隔: {result['actual_interval_formatted']}")
                print(f"  每小时调用: {result['actual_calls_per_hour']} 次")
                print("-" * 70)
            except ValueError:
                print("❌ 请输入有效的数字")
            print()

        elif choice == '3':
            print()
            print("=" * 70)
            print("常见场景对比")
            print("=" * 70)
            print()

            scenarios = [
                (5, "小型组合"),
                (10, "中型组合"),
                (15, "较大组合"),
                (20, "大型组合"),
                (30, "超大组合"),
                (50, "极大组合"),
            ]

            print(f"{'场景':<15} {'股票数':<8} {'检查间隔':<15} {'每小时调用':<12} {'安全性':<15}")
            print("-" * 70)

            for count, name in scenarios:
                result = calculate_frequency_from_stocks(count)
                print(f"{name:<15} {count:<8} {result['interval_formatted']:<15} "
                      f"{result['calls_per_hour']:<12} {result['safety']:<15}")

            print()

        elif choice == '4':
            print("再见！")
            break

        else:
            print("❌ 无效选择，请输入 1-4")
            print()


if __name__ == '__main__':
    print_interactive_calculator()
