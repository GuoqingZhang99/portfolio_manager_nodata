"""
实时价格监控程序
持续刷新显示股票价格，支持盘中实时监控
"""
import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32' and hasattr(sys.stdout, 'buffer'):
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except:
        pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from yahooquery import Ticker
from datetime import datetime
import time
import argparse


def clear_screen():
    """清屏"""
    os.system('cls' if os.name == 'nt' else 'clear')


def get_realtime_prices(symbols):
    """批量获取实时价格"""
    try:
        tickers = Ticker(symbols)
        prices_data = tickers.price

        results = []
        for symbol in symbols:
            if symbol in prices_data and isinstance(prices_data[symbol], dict):
                data = prices_data[symbol]

                # 获取市场状态
                market_state = data.get('marketState', 'UNKNOWN')

                # 根据市场状态获取价格
                if market_state == 'REGULAR':  # 盘中
                    price = data.get('regularMarketPrice')
                    change = data.get('regularMarketChange')
                    change_pct = data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    bid = data.get('bid')
                    ask = data.get('ask')
                elif market_state == 'POST':  # 盘后
                    price = data.get('postMarketPrice') or data.get('regularMarketPrice')
                    change = data.get('postMarketChange') or data.get('regularMarketChange')
                    change_pct = data.get('postMarketChangePercent') or data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    bid = data.get('bid')
                    ask = data.get('ask')
                elif market_state == 'PRE':  # 盘前
                    price = data.get('preMarketPrice') or data.get('regularMarketPrice')
                    change = data.get('preMarketChange') or data.get('regularMarketChange')
                    change_pct = data.get('preMarketChangePercent') or data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    bid = data.get('bid')
                    ask = data.get('ask')
                else:  # 休市
                    price = data.get('regularMarketPrice')
                    change = data.get('regularMarketChange')
                    change_pct = data.get('regularMarketChangePercent')
                    volume = data.get('regularMarketVolume')
                    bid = data.get('bid')
                    ask = data.get('ask')

                results.append({
                    'symbol': symbol,
                    'price': price,
                    'change': change or 0,
                    'change_pct': change_pct or 0,
                    'volume': volume,
                    'bid': bid,
                    'ask': ask,
                    'state': market_state,
                    'day_high': data.get('regularMarketDayHigh'),
                    'day_low': data.get('regularMarketDayLow'),
                })

        return results

    except Exception as e:
        print(f"获取数据失败: {e}")
        return []


def display_prices(results, interval, show_detail=False):
    """显示价格表格"""
    clear_screen()

    print("=" * 100)
    print(f"实时价格监控 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"刷新间隔: {interval}秒 | 按 Ctrl+C 停止")
    print("=" * 100)
    print()

    if not results:
        print("无数据")
        return

    # 表头
    if show_detail:
        print(f"{'股票':<8} {'状态':<8} {'价格':<10} {'涨跌额':<10} {'涨跌幅':<10} {'买价':<10} {'卖价':<10} {'成交量(M)':<12} {'日高':<10} {'日低':<10}")
        print("-" * 100)
    else:
        print(f"{'股票':<8} {'状态':<8} {'价格':<10} {'涨跌额':<10} {'涨跌幅':<10} {'成交量(M)':<12}")
        print("-" * 100)

    # 数据行
    for r in results:
        # 涨跌符号
        if r['change'] > 0:
            sign = "+"
            trend = "↑"
        elif r['change'] < 0:
            sign = ""
            trend = "↓"
        else:
            sign = " "
            trend = "→"

        # 市场状态中文
        state_cn = {
            'REGULAR': '盘中',
            'POST': '盘后',
            'PRE': '盘前',
            'CLOSED': '休市',
            'PREPRE': '准备中'
        }.get(r['state'], r['state'])

        # 成交量（百万）
        vol_m = r['volume'] / 1_000_000 if r['volume'] else 0

        if show_detail:
            bid_str = f"${r['bid']:.2f}" if r['bid'] else "N/A"
            ask_str = f"${r['ask']:.2f}" if r['ask'] else "N/A"
            high_str = f"${r['day_high']:.2f}" if r['day_high'] else "N/A"
            low_str = f"${r['day_low']:.2f}" if r['day_low'] else "N/A"

            print(f"{r['symbol']:<8} {state_cn:<8} ${r['price']:<9.2f} {sign}${abs(r['change']):<8.2f} {sign}{r['change_pct']:<9.2f}% {bid_str:<10} {ask_str:<10} {vol_m:<12.2f} {high_str:<10} {low_str:<10} {trend}")
        else:
            print(f"{r['symbol']:<8} {state_cn:<8} ${r['price']:<9.2f} {sign}${abs(r['change']):<8.2f} {sign}{r['change_pct']:<9.2f}% {vol_m:<12.2f} {trend}")

    print()
    print("=" * 100)

    # 显示汇总信息
    total_stocks = len(results)
    up_count = sum(1 for r in results if r['change'] > 0)
    down_count = sum(1 for r in results if r['change'] < 0)
    flat_count = total_stocks - up_count - down_count

    print(f"总计: {total_stocks} 只 | 上涨: {up_count} | 下跌: {down_count} | 持平: {flat_count}")
    print("=" * 100)


def monitor_prices(symbols, interval=30, show_detail=False):
    """持续监控价格"""
    print(f"\n开始监控 {len(symbols)} 只股票...")
    print(f"股票列表: {', '.join(symbols)}")
    print(f"刷新间隔: {interval} 秒")
    print(f"\n提示: 盘中时会显示实时价格变化")
    print("按 Ctrl+C 停止监控\n")
    time.sleep(2)

    try:
        while True:
            results = get_realtime_prices(symbols)
            display_prices(results, interval, show_detail)
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n\n监控已停止")
        print("=" * 100)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='实时股票价格监控')
    parser.add_argument('symbols', nargs='*', help='股票代码列表（如: MU PLTR NVDA）')
    parser.add_argument('-i', '--interval', type=int, default=30, help='刷新间隔（秒），默认30秒')
    parser.add_argument('-d', '--detail', action='store_true', help='显示详细信息（买卖价、日高低）')
    parser.add_argument('-p', '--portfolio', action='store_true', help='使用数据库中的持仓股票')

    args = parser.parse_args()

    # 确定监控的股票列表
    if args.portfolio:
        # 从数据库获取持仓股票
        try:
            from core.database import Database
            from core.calculator import PortfolioCalculator
            import config

            db = Database(config.DATABASE_PATH)
            calc = PortfolioCalculator(db)
            stocks = calc.calculate_stock_summary()

            if stocks.empty:
                print("数据库中没有持仓股票")
                return

            symbols = stocks['股票代码'].unique().tolist()
            print(f"\n从数据库加载了 {len(symbols)} 只持仓股票")

        except Exception as e:
            print(f"加载持仓股票失败: {e}")
            return

    elif args.symbols:
        symbols = [s.upper() for s in args.symbols]
    else:
        # 默认监控列表
        symbols = ['MU', 'PLTR', 'NVDA', 'TSLA', 'AMD', 'INTC', 'NFLX', 'ORCL']
        print(f"\n使用默认监控列表")

    # 开始监控
    monitor_prices(symbols, args.interval, args.detail)


if __name__ == "__main__":
    main()
